import 'package:flutter/material.dart';

import '../Auth/Login/UI/login_page.dart';


class Start extends StatefulWidget {
  const Start({super.key});

  @override
  State<Start> createState() => _StartState();
}

class _StartState extends State<Start> {
  List<String> gridImage = <String>[
  'assets/images/1.png',
  'assets/images/2.png',
  'assets/images/3.png',
  'assets/images/4.png',
  'assets/images/5.png',
  'assets/images/6.png',
  'assets/images/7.png',
  'assets/images/8.png',
  'assets/images/9.png', 
];
 List<String> gridText = <String>[
  'Singing',
  'Dancing',
  'Comedy',
  'Beauty',
  'Fasion',
  'Sports',
  'Acting',
  'Photography',
  'Hand Art', 
];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text(''),
        
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Text("chose your interests for  \n\t better reccomentions",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
            const SizedBox(height: 10,),
            GridView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                itemCount: gridImage.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 2 / 2.5,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 3,
                ),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {},
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.white12,
                          borderRadius: BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                        ),
                        child: Column(
                          children: [
                             Padding(
                               padding: const EdgeInsets.only(top: 30),
                               child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(gridImage[index]),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                    width: 35,
                                    height: 35,
                                  ),
                             ),
                              
                              
                            
                             Padding(
                               padding: const EdgeInsets.only(top: 40),
                               child: Text(gridText[index],style: const TextStyle(color: Colors.white),),
                             ),
                            
                          ],
                        ),

                      ),
                    ),
                  );
                }),
                const SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(onPressed: (){}, child: const Text("Skip")),
                const SizedBox(width: 10,),
                ElevatedButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginBody()));
                }, child: const Text("Next")),
              ],
            ),
          ],
        ),
        
      ),
    );
  }

}
