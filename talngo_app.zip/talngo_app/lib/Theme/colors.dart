import 'package:flutter/material.dart';

Color backgroundColor = Color(0xff000000);
Color mainColor = Color(0xff0de8d1);
Color secondaryColor = Colors.white;
Color disabledTextColor = Color(0xff6b717e);
Color lightTextColor = Color(0xff4cffffff);
Color transparentColor = Colors.transparent;
Color darkColor = Color(0xff151619);
Color fbColor = Color(0xff3c5a9a);
Color videoCall = Colors.red;

LinearGradient lGradient=LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.blue, Colors.purple,Colors.blue]);
      