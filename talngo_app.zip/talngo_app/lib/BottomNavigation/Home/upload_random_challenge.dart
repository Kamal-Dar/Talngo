import 'package:animation_wrappers/animation_wrappers.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_phoenix/flutter_phoenix.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:talngo_app/Components/profile_page_button.dart';
import 'package:talngo_app/Components/row_item.dart';
import 'package:talngo_app/Components/sliver_app_delegate.dart';
import 'package:talngo_app/Components/tab_grid.dart';
import 'package:talngo_app/Locale/locale.dart';
import 'package:talngo_app/Routes/routes.dart';
import 'package:talngo_app/BottomNavigation/MyProfile/edit_profile.dart';
import 'package:talngo_app/BottomNavigation/MyProfile/followers.dart';
import 'package:talngo_app/Theme/colors.dart';
import 'package:talngo_app/BottomNavigation/Explore/explore_page.dart';
import 'package:talngo_app/BottomNavigation/MyProfile/following.dart';

class UploadRandomPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return UploadRandomBody();
  }
}

class UploadRandomBody extends StatefulWidget {
  @override
  _MyProfileBodyState createState() => _MyProfileBodyState();
}

class _MyProfileBodyState extends State<UploadRandomBody> {
  final key = UniqueKey();
  final List<String> categoryList = ['Eating', 'Singing', 'Dancing'];

  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context);
    return Padding(
      padding: EdgeInsets.only(bottom: 0),
      child: Container(
        decoration:  BoxDecoration(
          gradient: lGradient),
        child: Scaffold(
            backgroundColor: transparentColor,
            appBar: AppBar(
              title: Column(
                children: [
                  Center(
                      child: Text("Create Challenge",
                          style: GoogleFonts.poppins(fontSize: 14))),
                ],
              ),
              bottom: PreferredSize(
                preferredSize: Size.square(2.0),
                child: Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
            ),
            body: FadedSlideAnimation(
              ListView(
                physics: BouncingScrollPhysics(),
                children: [
                  SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.transparent,
                                        image: DecorationImage(
                                          image:
                                              AssetImage('assets/images/111.png'),
                                          fit: BoxFit.cover,
                                        ),
                                        ),
                                    width: 130,
                                    height: 130,
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 18, right: 8),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              image: DecorationImage(
                                                image: AssetImage(
                                                    'assets/images/p2.jpg'),
                                                fit: BoxFit.cover,
                                              ),
                                              shape: BoxShape.circle),
                                          width: 90,
                                          height: 90,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("@You",
                                      style: GoogleFonts.poppins(fontSize: 12))
                                ],
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    image: DecorationImage(
                                      image:
                                      AssetImage('assets/images/444.png'),
                                      fit: BoxFit.cover,
                                    ),
                                   ),
      
      
                              ),
                              /*Text("VS",
                                  style: GoogleFonts.poppins(
                                      fontSize: 20,
                                      textStyle: TextStyle(
                                          fontWeight: FontWeight.bold))),*/
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.transparent,
                                        image: DecorationImage(
                                          image:
                                              AssetImage('assets/images/111.png'),
                                          fit: BoxFit.cover,
                                        ),
                                        ),
                                    width: 130,
                                    height: 130,
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 18, right: 8),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              image: DecorationImage(
                                                image: AssetImage(
                                                    'assets/images/p3.jpg'),
                                                fit: BoxFit.cover,
                                              ),
                                              shape: BoxShape.circle),
                                          width: 90,
                                          height: 90,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("@Opponent",
                                      style: GoogleFonts.poppins(fontSize: 12))
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Divider(
                            thickness: 1,
                            color: Colors.grey,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 15),
                            child: Text("Title",
                                style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    textStyle:
                                        TextStyle(fontWeight: FontWeight.bold))),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextField(
                                style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    textStyle: TextStyle(color: Colors.white)),
                                decoration: InputDecoration(
                                    isDense: true,
                                    contentPadding: EdgeInsets.all(10),
                                    hintText: "Lemon Eating Challenge",
                                    hintStyle: GoogleFonts.poppins(
                                        fontSize: 14,
                                        textStyle: TextStyle(color: Colors.grey)),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey.shade600),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey.shade600),
                                      borderRadius: BorderRadius.circular(10),
                                    )),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Padding(
                              padding: const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("Category",
                                      style: GoogleFonts.poppins(
                                          fontSize: 14,
                                          textStyle: TextStyle(
                                              fontWeight: FontWeight.bold))),
                                  GestureDetector(
                                    onTap: () {
                                      bottomSheet(context);
                                    },
                                    child: Container(
                                      height: 20,
                                      width: 20,
                                      decoration: BoxDecoration(
                                          color: Colors.blue,
                                          shape: BoxShape.circle),
                                      child: Center(
                                        child: Icon(
                                          Icons.add,
                                          color: Colors.white,
                                          size: 18,
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              )),
                          SizedBox(height: 15),
                          Padding(
                              padding: const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    height: 20,
                                    width: 20,
                                    decoration: BoxDecoration(
                                        color: Colors.transparent,
                                        shape: BoxShape.circle),
                                    child: Center(
                                      child: Icon(
                                        Icons.info_outline,
                                        color: Colors.white,
                                        size: 18,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                        "Select category or create your own category using #tag e.g #swimming, Only 4 tags can be added! ",
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.poppins(
                                            fontSize: 12,
                                            textStyle: TextStyle(
                                                fontWeight: FontWeight.normal))),
                                  ),
                                ],
                              )),
                          SizedBox(height: 10),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: 150,
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(5)),
                              child: GridView.builder(
                                  physics: BouncingScrollPhysics(),
                                  itemCount: categoryList.length,
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    childAspectRatio: (100 / 35),
                                    crossAxisSpacing: 2,
                                    mainAxisSpacing: 10,
                                  ),
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () {},
                                      child: FadedScaleAnimation(
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 5, right: 5, top: 5),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(10.0),
                                              ),
                                            ),
                                            child: Center(
                                              child: TextField(
                                                style: GoogleFonts.poppins(
                                                    fontSize: 14,
                                                    textStyle: TextStyle(
                                                        color: Colors.white)),
                                                decoration: InputDecoration(
                                                    isDense: true,
                                                    contentPadding:
                                                        EdgeInsets.only(left: 8),
                                                    hintText: categoryList[index],
                                                    suffixIcon: IconButton(
                                                      alignment:
                                                          Alignment.centerRight,
                                                      icon: Icon(
                                                        Icons.close,
                                                        size: 15,
                                                      ),
                                                      color: secondaryColor,
                                                      onPressed: () {
                                                        setState(() {
                                                          categoryList
                                                              .removeAt(index);
                                                        });
                                                      },
                                                    ),
                                                    hintStyle:
                                                        GoogleFonts.poppins(
                                                            fontSize: 10,
                                                            textStyle: TextStyle(
                                                                color:
                                                                    Colors.grey)),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: Colors.white),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: Colors
                                                              .grey.shade600),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                    )),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Padding(
                              padding: const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("Description",
                                      style: GoogleFonts.poppins(
                                          fontSize: 14,
                                          textStyle: TextStyle(
                                              fontWeight: FontWeight.bold))),
                                  Row(
                                    children: [
                                      Text("( 100 ",
                                          style:
                                              GoogleFonts.poppins(fontSize: 12)),
                                      Text("/ 1000 )",
                                          style:
                                              GoogleFonts.poppins(fontSize: 12))
                                    ],
                                  )
                                ],
                              )),
                          SizedBox(height: 15),
                          Padding(
                              padding: const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    height: 20,
                                    width: 20,
                                    decoration: BoxDecoration(
                                        color: Colors.transparent,
                                        shape: BoxShape.circle),
                                    child: Center(
                                      child: Icon(
                                        Icons.info_outline,
                                        color: Colors.white,
                                        size: 18,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                        "describe your challenge and tag your friend @tag e.g @name! ",
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.poppins(
                                            fontSize: 12,
                                            textStyle: TextStyle(
                                                fontWeight: FontWeight.normal))),
                                  ),
                                ],
                              )),
                          SizedBox(height: 10),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextField(
                                maxLines: 10,
                                style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    textStyle: TextStyle(color: Colors.white)),
                                decoration: InputDecoration(
                                    isDense: true,
                                    contentPadding: EdgeInsets.all(10),
                                    hintText: "Hi, this is description bolck",
                                    hintStyle: GoogleFonts.poppins(
                                        fontSize: 14,
                                        textStyle: TextStyle(color: Colors.grey)),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey.shade600),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey.shade600),
                                      borderRadius: BorderRadius.circular(10),
                                    )),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Padding(
                              padding: const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text("Upload Video",
                                      style: GoogleFonts.poppins(
                                          fontSize: 14,
                                          textStyle: TextStyle(
                                              fontWeight: FontWeight.bold))),
                                ],
                              )),
                          /*Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: DottedBorder(
                                color: Colors.white,
                                dashPattern: [8, 4],
                                strokeWidth: 2,
                                child: Container(
                                  height: 200,
                                  decoration: BoxDecoration(
                                      color: Colors.white12,
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Center(
                                    child: Icon(
                                      Icons.camera_alt,
                                      color: Colors.white,
                                      size: 40,
                                    ),
                                  ),
                                ),
                              )),*/
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 50, right: 50, top: 5, bottom: 5),
                            child:
                            GestureDetector(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, PageRoutes.bottomNavigation);
                              },
                              child: Container(
                                height: 35,
                                decoration: BoxDecoration(
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Center(
                                    child: Text("Upload Challenge",
                                        style: GoogleFonts.poppins(
                                            fontSize: 14,
                                            textStyle:
                                                TextStyle(color: Colors.white)))),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              beginOffset: Offset(0, 0.3),
              endOffset: Offset(0, 0),
              slideCurve: Curves.linearToEaseOut,
            )),
      ),
    );
  }
}

void bottomSheet(context) {
  int selectedRadio = 0;
  final List<String> categoryList = ["Reaction", "Dancing", "Singing"];

  showModalBottomSheet(
      enableDrag: false,
      isScrollControlled: true,
      backgroundColor: backgroundColor,
      shape: OutlineInputBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
          borderSide: BorderSide.none),
      context: context,
      builder: (context) => Container(
            height: MediaQuery.of(context).size.height / 2.5,
            child: Stack(
              children: <Widget>[
                FadedSlideAnimation(
                  StatefulBuilder(builder: (context, setState) {
                    return ListView.builder(
                        physics: BouncingScrollPhysics(),
                        padding: EdgeInsets.only(bottom: 10.0),
                        itemCount: categoryList.length,
                        itemBuilder: (context, index) {
                          return Column(
                            children: <Widget>[
                              Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.grey,
                                    disabledColor: Colors.grey),
                                child: RadioListTile(
                                  value: categoryList[index],
                                  groupValue: categoryList[index],
                                  title: Text(categoryList[index].toString(),
                                      style: GoogleFonts.poppins(
                                          fontSize: 14,
                                          textStyle:
                                              TextStyle(color: Colors.grey))),
                                  onChanged: (dynamic val) {
                                    setState(() {
                                      categoryList[index] = val;
                                    });
                                  },
                                  activeColor: Colors.white,
                                ),
                              ),
                            ],
                          );
                        });
                  }),
                  beginOffset: Offset(0, 0.3),
                  endOffset: Offset(0, 0),
                  slideCurve: Curves.linearToEaseOut,
                ),
              ],
            ),
          ));
}
