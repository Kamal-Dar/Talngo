import 'package:animation_wrappers/Animations/faded_slide_animation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:talngo_app/BottomNavigation/Home/play_random_challenge.dart';
import 'package:talngo_app/BottomNavigation/Home/random_challenge_dialog.dart';
import 'package:talngo_app/Components/custom_button.dart';

import '../../Components/rotated_image.dart';
import '../../Locale/locale.dart';
import '../../Routes/routes.dart';
import '../../Theme/colors.dart';
import '../tournament/tournament_screen.dart';
import 'comment_sheet.dart';
import 'filter_sheet.dart';

class Challenges_tab extends StatefulWidget {
  const Challenges_tab({Key? key}) : super(key: key);

  @override
  State<Challenges_tab> createState() => _Challenges_tabState();
}

class _Challenges_tabState extends State<Challenges_tab> {
  late int selectedRadio;
  var search_controller = TextEditingController();


  final List<String> _radioText = [
    'Play a Random Challange',
    'Upload a Random Challenge'
  ];

  @override
  void initState() {
    super.initState();
    selectedRadio = 0;
  }
  @override
  Widget build(BuildContext context) {

    return Container(
       decoration:  BoxDecoration(
          gradient: lGradient),
      child: Scaffold(
          resizeToAvoidBottomInset: true,
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(50.0),
              child: Column(
                children: <Widget>[
                  Container(
                    margin:
                    EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
                    decoration: BoxDecoration(
                      color: secondaryColor,
                      borderRadius: BorderRadius.circular(25.0),
                    ),
                    child: TextField(
                      controller: search_controller,
                      decoration: InputDecoration(
                          icon: IconButton(
                            icon: Icon(Icons.mic),
                            color: Colors.grey,
                            onPressed: () => Navigator.pop(context),
                          ),
                          border: InputBorder.none,
                          hintText: AppLocalizations.of(context)!.search,
                          hintStyle: Theme.of(context).textTheme.subtitle1,
                          suffixIcon: IconButton(
                            icon: Icon(Icons.search),
                            color: Colors.grey,
                            onPressed: () {
                              search_controller.clear();
                            },
                          )),
                    ),
                  ),
    
                ],
              ),
            ),
          ),
          body: Stack(
    
            children:<Widget>[
              FadedSlideAnimation(
                Padding(
                  padding: const EdgeInsets.only(left: 5,right:20,bottom: 50),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
    
                      Expanded(child: ListView(
                        physics: BouncingScrollPhysics(),
                        scrollDirection: Axis.vertical,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(10)),
    
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20),
                                    child: Center(child:
                                    Text("Lemon Eating Challenge",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(fontWeight: FontWeight.bold))
                                    )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
    
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
    
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p2.jpg'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
                                          ],
                                        ),
    
                                        SizedBox(width: 10,),
                                        Text("VS",style: GoogleFonts.poppins(fontSize: 20,textStyle: TextStyle(fontWeight: FontWeight.bold))),
                                        SizedBox(width: 10,),
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p3.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p3.jpg'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5,),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
    
                                          ],
                                        ),
    
    
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                      height: 30,
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius: BorderRadius.circular(30)),
                                      child: Center(child: Text("Voting Open",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                                    ),
                                  )
                                ],
                              ),
    
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(10)),
    
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20),
                                    child: Center(child:
                                    Text("Lemon Eating Challenge",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(fontWeight: FontWeight.bold))
                                    )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
    
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
    
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p2.jpg'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
                                          ],
                                        ),
    
                                        SizedBox(width: 10,),
                                        Text("VS",style: GoogleFonts.poppins(fontSize: 20,textStyle: TextStyle(fontWeight: FontWeight.bold))),
                                        SizedBox(width: 10,),
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p3.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p3.jpg'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5,),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
    
                                          ],
                                        ),
    
    
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                      height: 30,
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius: BorderRadius.circular(30)),
                                      child: Center(child: Text("Voting Open",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                                    ),
                                  )
                                ],
                              ),
    
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(10)),
    
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20),
                                    child: Center(child:
                                    Text("Lemon Eating Challenge",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(fontWeight: FontWeight.bold))
                                    )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
    
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
    
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p2.jpg'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
                                          ],
                                        ),
    
                                        SizedBox(width: 10,),
                                        Text("VS",style: GoogleFonts.poppins(fontSize: 20,textStyle: TextStyle(fontWeight: FontWeight.bold))),
                                        SizedBox(width: 10,),
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p3.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p3.jpg'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5,),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
    
                                          ],
                                        ),
    
    
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                      height: 30,
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius: BorderRadius.circular(30)),
                                      child: Center(child: Text("Voting Open",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                                    ),
                                  )
                                ],
                              ),
    
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(10)),
    
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20),
                                    child: Center(child:
                                    Text("Lemon Eating Challenge",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(fontWeight: FontWeight.bold))
                                    )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
    
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
    
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p2.jpg'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
                                          ],
                                        ),
    
                                        SizedBox(width: 10,),
                                        Text("VS",style: GoogleFonts.poppins(fontSize: 20,textStyle: TextStyle(fontWeight: FontWeight.bold))),
                                        SizedBox(width: 10,),
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p3.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p3.jpg'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5,),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
    
                                          ],
                                        ),
    
    
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                      height: 30,
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius: BorderRadius.circular(30)),
                                      child: Center(child: Text("Voting Open",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                                    ),
                                  )
                                ],
                              ),
    
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white12,
                                  borderRadius: BorderRadius.circular(10)),
    
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20),
                                    child: Center(child:
                                    Text("Lemon Eating Challenge",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(fontWeight: FontWeight.bold))
                                    )),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
    
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
    
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p2.jpg'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
                                          ],
                                        ),
    
                                        SizedBox(width: 10,),
                                        Text("VS",style: GoogleFonts.poppins(fontSize: 20,textStyle: TextStyle(fontWeight: FontWeight.bold))),
                                        SizedBox(width: 10,),
                                        Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p3.jpg'),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  borderRadius: BorderRadius.circular(20)),
                                              width: 100,
                                              height:150,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          image: AssetImage(
                                                              'assets/icons/transparent_play.png'),
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      width: 40,
                                                      height:40,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 5,),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 20,
                                                  height: 20,
                                                  decoration: BoxDecoration(
    
                                                      color: Colors.white,
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/images/p3.jpg'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                      borderRadius: BorderRadius.circular(30)),
    
                                                ),
                                                SizedBox(width: 5,),
                                                Text("@Name",style: GoogleFonts.poppins(fontSize: 12))
                                              ],
                                            ),
    
    
                                          ],
                                        ),
    
    
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                      height: 30,
                                      decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                          borderRadius: BorderRadius.circular(30)),
                                      child: Center(child: Text("Voting Open",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                                    ),
                                  )
                                ],
                              ),
    
                            ),
                          ),
    
                        ],
                      )),
                      Container(height: 10,width: 10,
                      )
    
                    ],
                  ),
                ),
                beginOffset: Offset(0, 0.3),
                endOffset: Offset(0, 0),
                slideCurve: Curves.linearToEaseOut,
    
              ),
              Positioned.directional(
                
                textDirection: Directionality.of(context),
                end: -10.0,
                bottom: (MediaQuery.of(context).size.width/1.5),
                child: Column(
                  children: <Widget>[
                    CustomButton(
                      Icon(Icons.filter_alt,color: Colors.white,),
                      'Filter', onPressed: () {
                      FilterSheet(context);
      }
                    ),
                    SizedBox(height: 15,),
                    CustomButton(
                      Icon(Icons.account_tree,color: Colors.white, ),
                      'Tournament',
                      onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Tournament_Page()));},
                    ),
                    SizedBox(height: 15,),
                    CustomButton(
                        Icon(Icons.grid_view_sharp,color: Colors.white, ),
                        'Random\nChallenges', onPressed: () {
                      showCustomDialog(context);
                    }),
    
    
                    
                  ],
                ),
              )
    
            ]
    
          )
    
      ),
    );
  }
  void showCustomDialog(BuildContext context) {

    showDialog(
      context: context,
      barrierColor: Colors.grey.withOpacity(0.5),
      builder: (context)
        {
          selectedRadio = -1;
          return
            StatefulBuilder(builder:(context,setState)
          {
            return Center(
              child: Container(
                height: 240,
                
                child: SizedBox.expand(
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Padding(
                            padding: const EdgeInsets.only(left: 30),
                            child: Text("What do you want to do? ",textAlign: TextAlign.left,style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white))),
                          ),
                          SizedBox(height: 20,),
                          Theme(
                            data: Theme.of(context).copyWith(
                                   unselectedWidgetColor: Colors.grey,
                                disabledColor: Colors.grey,
                            ),
                            child: RadioListTile(
                              value: 0,
                              groupValue: selectedRadio,
                              title: Text("Play a Random Challange",style: GoogleFonts.poppins(fontSize: 14,color: Colors.white)),

                              onChanged: (dynamic val) {
                                setState(() {
                                  selectedRadio = val;
                                });
                              },
                              activeColor: Colors.white,

                            ),
                          ),
                          Theme(
                            data: Theme.of(context).copyWith(
                                unselectedWidgetColor: Colors.grey,
                                disabledColor: Colors.grey,
                            ),
                            child: RadioListTile(
                              value: 1,
                              groupValue: selectedRadio,
                              title: Text("Upload a Random Challenge",style: GoogleFonts.poppins(fontSize: 14,color: Colors.white)),

                              onChanged: (dynamic val) {
                                setState(() {
                                  selectedRadio = val;
                                });
                              },
                              activeColor: Colors.white,

                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(left: 50,right: 50,top: 5,bottom: 5),
                            child: GestureDetector(
                              onTap: (){
                                if(selectedRadio==0)
                                  {
                                    Navigator.pushNamed(context, PageRoutes.playRandom);
                                  }
                                else if(selectedRadio==1)
                                  {
                                    Navigator.pushNamed(context, PageRoutes.uploadRandom);
                                  }

                              },
                              child: Container(
                                height: 35,
                                decoration: BoxDecoration(
                                    color: Colors.blueAccent,
                                    borderRadius: BorderRadius.circular(30)),
                                child: Center(child: Text("Next",style: GoogleFonts.poppins(fontSize: 14,textStyle: TextStyle(color:Colors.white)))),
                              ),
                            ),
                          )

                        ],
                      ),
                    ),
                  ),),

                margin: EdgeInsets.symmetric(horizontal: 20),
                decoration:  BoxDecoration(
          gradient: lGradient,
          borderRadius: BorderRadius.circular(10)),
              ),
            );
          });
        }
    );
  }
  setSelectedRadio(int val) {
    setState(() {
      selectedRadio = val;
    });
  }

}
