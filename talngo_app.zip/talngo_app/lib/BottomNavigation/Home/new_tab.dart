import 'package:flutter/material.dart';
class Newstab extends StatefulWidget {
  const Newstab({Key? key}) : super(key: key);

  @override
  State<Newstab> createState() => _NewstabState();
}

class _NewstabState extends State<Newstab> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Container(
          child: Text("News"),
        ),
      ),
    );
  }
}
