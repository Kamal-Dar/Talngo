import 'package:animation_wrappers/Animations/faded_scale_animation.dart';
import 'package:animation_wrappers/Animations/faded_slide_animation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../Components/tab_grid.dart';
import '../../Routes/routes.dart';
import '../../Theme/colors.dart';
import '../Explore/explore_page.dart';

class Edit_Profile extends StatefulWidget {
  const Edit_Profile({Key? key}) : super(key: key);

  @override
  State<Edit_Profile> createState() => _Edit_profileState();
}

class _Edit_profileState extends State<Edit_Profile> {
  late TabController _controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(bottom: 0),
        child: Container(
          decoration:  BoxDecoration(
          gradient: lGradient),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Scaffold(
              backgroundColor: transparentColor,
              appBar: AppBar(
                automaticallyImplyLeading: false,
                title: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5),
                        child: Container(
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.white),
                              shape: BoxShape.circle),
                          child: Padding(
                            padding: const EdgeInsets.all(2),
                            child: Icon(
                              Icons.arrow_back_rounded,
                              size: 18,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text("@Username", style: GoogleFonts.poppins(fontSize: 14))
                    ],
                  ),
                ),
                bottom: PreferredSize(
                  preferredSize: Size.square(2.0),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Divider(
                      thickness: 1,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
              body: FadedSlideAnimation(
                ListView(
                  physics: BouncingScrollPhysics(),
                  children: [
                    Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child:
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Stack(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            image: DecorationImage(
                                              image: AssetImage(
                                                  'assets/images/p3.jpg'),
                                              fit: BoxFit.cover,
                                            ),
                                            shape: BoxShape.circle),
                                        width: 100,
                                        height: 100,
                                        child: Align(
                                          child: Container(
                                            margin: EdgeInsets.only(top: 80),
                                            decoration: BoxDecoration(
                                                color: Colors.transparent,
                                                shape: BoxShape.circle),
                                            child: Icon(
                                              Icons.camera_alt_rounded,
                                              color: Colors.blue,
                                              size: 40,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      /*RatingBar.builder(
                                        initialRating: 3,
                                        minRating: 1,
                                        direction: Axis.horizontal,
                                        allowHalfRating: true,
                                        unratedColor: Colors.amber.withAlpha(50),
                                        itemCount: 5,
                                        itemSize: 20.0,
                                        itemPadding:
                                            EdgeInsets.symmetric(horizontal: 4.0),
                                        itemBuilder: (context, _) => Icon(
                                          Icons.star,
                                          color: Colors.white,
                                        ),
                                        onRatingUpdate: (rating) {
                                          setState(() {});
                                        },
                                        updateOnDrag: true,
                                      ),*/
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text("Superstar",
                                          style: GoogleFonts.poppins(
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold)),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Row(
                                        children: [
                                          Text("@Username",
                                              style: GoogleFonts.poppins(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold)),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                                color: Colors.blue,
                                                shape: BoxShape.circle),
                                            width: 20,
                                            height: 20,
                                            child: Center(
                                                child: Icon(
                                              Icons.edit,
                                              size: 11,
                                              color: Colors.white,
                                            )),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Row(
                                        children: [
                                          Text("User Full name",
                                              style: GoogleFonts.poppins(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold)),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                                color: Colors.blue,
                                                shape: BoxShape.circle),
                                            width: 20,
                                            height: 20,
                                            child: Center(
                                                child: Icon(
                                              Icons.edit,
                                              size: 11,
                                              color: Colors.white,
                                            )),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Row(
                                        children: [
                                          Text("add bio",
                                              style: GoogleFonts.poppins(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold)),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                                color: Colors.blue,
                                                shape: BoxShape.circle),
                                            width: 20,
                                            height: 20,
                                            child: Center(
                                                child: Icon(
                                              Icons.edit,
                                              size: 11,
                                              color: Colors.white,
                                            )),
                                          ),
                                        ],
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            Divider(
                              thickness: 1,
                              color: Colors.grey,
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("Manage Account",
                                      style: GoogleFonts.poppins(fontSize: 13)),
                                  Icon(
                                    Icons.navigate_next,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                ],
                              ),
                            ),
                             Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("private Account",
                                      style: GoogleFonts.poppins(fontSize: 13)),
                                  Icon(
                                    Icons.toggle_on,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                ],
                              ),
                            ),
                           
                            SingleChildScrollView(
                              child: SizedBox(
                                height: 600,
                                child: DefaultTabController(
                                  length: 3,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: transparentColor,
                                       ),
                                    child: new Scaffold(
                                      backgroundColor: transparentColor,
                                      appBar: TabBar(
                                        indicator: UnderlineTabIndicator(
                                          borderSide: BorderSide(
                                              color: Colors.white, width: 2),
                                        ),
                                        isScrollable: true,
                                        labelColor: Colors.white,
                                        unselectedLabelColor: disabledTextColor,
                                        tabs: <Widget>[
                                          Tab(text: "Your Videos"),
                                          Tab(text: "Likes"),
                                          Tab(text: "Challenges"),
                                        ],
                                      ),
                                      body: TabBarView(
                                        children: <Widget>[
                                          FadedSlideAnimation(
                                      GridView.builder(
                                          physics: BouncingScrollPhysics(),
                                        itemCount: 5,
                                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 3,
                                          childAspectRatio: 2 / 2.5,
                                          crossAxisSpacing: 2,
                                          mainAxisSpacing: 2,
                                        ),
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            onTap: () {},
                                            child: FadedScaleAnimation(
                                              Container(
                                                height: 100,
                                          
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                        'assets/images/p2.jpg'),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius: BorderRadius.all(
                                                    Radius.circular(10.0),
                                                  ),
                                                ),
                                                child: Center(
                                                  child:
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                            'assets/icons/transparent_play.png'),
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    width: 35,
                                                    height:35,
                                                  ),
                                                ),
                                              ),
                                          
                                            ),
                                          );
                                        }),
                                            beginOffset: Offset(0, 0.3),
                                            endOffset: Offset(0, 0),
                                            slideCurve: Curves.linearToEaseOut,
                                          ),
                                          FadedSlideAnimation(
                                            GridView.builder(
                                                physics: BouncingScrollPhysics(),
                                                itemCount: 5,
                                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 3,
                                                  childAspectRatio: 2 / 2.5,
                                          
                                                ),
                                                itemBuilder: (context, index) {
                                                  return GestureDetector(
                                                    onTap: () {},
                                                    child: FadedScaleAnimation(
                                                      Container(
                                                        height: 100,
                                          
                                                        decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          image: DecorationImage(
                                                            image: AssetImage(
                                                                'assets/images/p2.jpg'),
                                                            fit: BoxFit.fill,
                                                          ),
                                                          borderRadius: BorderRadius.all(
                                                            Radius.circular(10.0),
                                                          ),
                                                        ),
                                                        child: Center(
                                                          child:
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              image: DecorationImage(
                                                                image: AssetImage(
                                                                    'assets/icons/transparent_play.png'),
                                                                fit: BoxFit.fill,
                                                              ),
                                                            ),
                                                            width: 35,
                                                            height:35,
                                                          ),
                                                        ),
                                                      ),
                                          
                                                    ),
                                                  );
                                                }),
                                            beginOffset: Offset(0, 0.3),
                                            endOffset: Offset(0, 0),
                                            slideCurve: Curves.linearToEaseOut,
                                          ),
                                          FadedSlideAnimation(
                                              GridView.builder(
                                                  physics: BouncingScrollPhysics(),
                                                  itemCount: 15,
                                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                                    crossAxisCount: 3,
                                                    childAspectRatio: 2 / 2.5,
                                                    crossAxisSpacing: 5,
                                                    mainAxisSpacing: 5,
                                                  ),
                                                  itemBuilder: (context, index) {
                                                    return GestureDetector(
                                                      onTap: () {},
                                                      child: FadedScaleAnimation(
                                                        Container(
                                                          height: 100,
                                          
                                                          decoration: BoxDecoration(
                                                            color: Colors.white,
                                                            image: DecorationImage(
                                                              image: AssetImage(
                                                                  'assets/images/p2.jpg'),
                                                              fit: BoxFit.fill,
                                                            ),
                                                            borderRadius: BorderRadius.all(
                                                              Radius.circular(10.0),
                                                            ),
                                                          ),
                                                          child: Center(
                                                            child:
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                image: DecorationImage(
                                                                  image: AssetImage(
                                                                      'assets/icons/transparent_play.png'),
                                                                  fit: BoxFit.fill,
                                                                ),
                                                              ),
                                                              width: 35,
                                                              height:35,
                                                            ),
                                                          ),
                                                        ),
                                          
                                                      ),
                                                    );
                                                  }),
                                            beginOffset: Offset(0, 0.3),
                                            endOffset: Offset(0, 0),
                                            slideCurve: Curves.linearToEaseOut,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
        
                            // create widgets for each tab bar here
                          ],
                        )),
                  ],
                ),
                beginOffset: Offset(0, 0.3),
                endOffset: Offset(0, 0),
                slideCurve: Curves.linearToEaseOut,
              ),
            ),
          ),
        ));
  }
}
