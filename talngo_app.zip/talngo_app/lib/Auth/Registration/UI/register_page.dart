import 'dart:convert';

import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:talngo_app/Components/continue_button.dart';
import 'package:talngo_app/Components/entry_field.dart';
import 'package:talngo_app/Locale/locale.dart';
import 'package:talngo_app/Theme/colors.dart';

import '../../../Routes/routes.dart';
import '../../Login/UI/login_page.dart';
import '../../login_navigator.dart';
import 'package:http/http.dart' as http;

//register page for registration of a new user
class RegisterPage extends StatefulWidget {
  RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(gradient: lGradient),
      child: Scaffold(
        backgroundColor: transparentColor,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop();
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.white),
                          shape: BoxShape.circle),
                      child: Padding(
                        padding: const EdgeInsets.all(2),
                        child: Icon(
                          Icons.arrow_back_rounded,
                          size: 15,
                        ),
                      ),
                    ),
                  ),
                ),
                Text("SignUp for Talngo",
                    style: GoogleFonts.poppins(fontSize: 14)),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: Padding(
                      padding: const EdgeInsets.all(2),
                      child: Icon(
                        Icons.info_outline,
                        size: 22,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          bottom: PreferredSize(
            preferredSize: Size.square(2.0),
            child: Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Divider(
                thickness: 1,
                color: Colors.grey,
              ),
            ),
          ),
        ),

        //this column contains 3 textFields and a bottom bar
        body: FadedSlideAnimation(
          RegisterForm(),
          beginOffset: Offset(0, 0.3),
          endOffset: Offset(0, 0),
          slideCurve: Curves.linearToEaseOut,
        ),
      ),
    );
  }
}

class RegisterForm extends StatefulWidget {
  @override
  _RegisterFormState createState() => _RegisterFormState();
}

class _RegisterFormState extends State<RegisterForm> {
  String countryValue = '+92';
  bool _isObscure = true;
  final GlobalKey<FormState> _key = new GlobalKey<FormState>();

  TextEditingController userNameController = TextEditingController();
  TextEditingController fullNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController countryController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPsswordController = TextEditingController();
  TextEditingController roleController = TextEditingController();

  void register(String userName, fullName, email, phone, country, password,
      confirmPassword, role) async {
    if (!_key.currentState!.validate()) {
      Fluttertoast.showToast(
            msg: "Kindly Provide all the details",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.yellow);
    } else {
       // show  loading cirrcular progress indecator
        showDialog(
          context: context, 
          builder: (context){
            return Center(child: CircularProgressIndicator());
          }
        );

      try {
      final response = await http
          .post(Uri.parse("https://talngo.com/api/auth/register"), body: {
        'username': userName,
        'name': fullName,
        'email': email,
        'phone': phone,
        'country': country,
        'password': password,
        'password_confirmation': confirmPassword,
        'role': role,
      });
      var res = jsonDecode(response.body);
      print("Register Response==> ${response.body}");
      if (res["status"] == 200) {
        showCustomDialog(context);
        Fluttertoast.showToast(
            msg: "Registed Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.yellow);
      } else {
        Fluttertoast.showToast(
            msg: res["message"],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.yellow);
      }
    } catch (e) {
      print(e.toString());
    }
      // print("UserName: " + userName);
      // print("FullName: " + fullName);
      // print("Email: " + email);
      // print("Phone: " + phone);
      // print("Country: " + country);
      // print("Password: " + password);
      // print("Confirm Password: " + confirmPassword);
      // print("Role: " + role);
      // print('Account creation failed');
    }
    
  }

  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Form(
      key: _key,
      child: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(color: transparentColor),
          padding: EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: 20,
              ),
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/icons/icon.png'),
                    ),
                  ),
                ),
              ),
              //name textField
              SizedBox(
                height: 20,
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 5, right: 5),
                  child: Text(
                      "Create a profile, follow other accounts,accept\n challenges, create your own video and\n much more",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                      )),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter user name';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: userNameController,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 20,
                    ),
                    focusColor: Colors.white,
                    contentPadding: EdgeInsets.only(left: 10),
                    label: Text(
                      "Create Username",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(8.0),
                      ),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(8.0),
                        ),
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter full name';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: fullNameController,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 20,
                    ),
                    contentPadding: EdgeInsets.only(left: 10),
                    label: Text(
                      "Full Name",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),

              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter a valid email';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: emailController,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.email,
                      color: Colors.white,
                      size: 20,
                    ),
                    contentPadding: EdgeInsets.only(left: 10),
                    label: Text(
                      "Enter Email Address",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),

              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter a valid phone number';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: phoneController,
                  decoration: InputDecoration(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: DropdownButton<String>(
                        // Step 3.
                        // isExpanded: true,
                        value: countryValue,
                        selectedItemBuilder: (BuildContext context) {
                          return <String>[
                            '+1',
                            '+90',
                            '+91',
                            '+92',
                            '+93',
                            '+94',
                            '+95',
                            '+96',
                            '+97',
                          ].map((String value) {
                            return Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                countryValue,
                                style: GoogleFonts.poppins(
                                    fontSize: 14, color: Colors.white),
                              ),
                            );
                          }).toList();
                        },
                        iconEnabledColor: Colors.white,
                        // Step 4.
                        items: <String>[
                          '+1',
                          '+90',
                          '+91',
                          '+92',
                          '+93',
                          '+94',
                          '+95',
                          '+96',
                          '+97',
                        ].map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value,
                                style: GoogleFonts.poppins(
                                    fontSize: 14, color: Colors.black)),
                          );
                        }).toList(),
                        // Step 5.
                        underline: Container(),
                        onChanged: (String? newValue) {
                          // Navigator.of(context).pop();
                          setState(() {
                            
                            countryValue = newValue!;
                            
                          });
                        },
                      ),
                    ),
                    contentPadding: EdgeInsets.only(left: 10),
                    label: Text(
                      "Phone",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),

              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a strong password';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: passwordController,
                  obscureText: _isObscure,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.lock,
                      color: Colors.white,
                      size: 20,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _isObscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () {
                        setState(() {
                          _isObscure = !_isObscure;
                        });
                      },
                      color: Colors.white,
                    ),
                    label: Text(
                      "Type Password",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(8.0),
                      ),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(8.0),
                        ),
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter a matched password';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: confirmPsswordController,
                  obscureText: _isObscure,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.lock,
                      color: Colors.white,
                      size: 20,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _isObscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () {
                        setState(() {
                          _isObscure = !_isObscure;
                        });
                      },
                      color: Colors.white,
                    ),
                    label: Text(
                      "Confirm Password",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(8.0),
                      ),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5, right: 5),
                child: TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Pleases enter your role';
                    }
                    return null;
                  },
                  style: TextStyle(color: Colors.white),
                  controller: roleController,
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 20,
                    ),
                    contentPadding: EdgeInsets.only(left: 10),
                    label: Text(
                      "Role",
                      textAlign: TextAlign.center,
                    ),
                    hintStyle: TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(8.0),
                      ),
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)),
                    labelStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 5, right: 5),
                  child: Text(
                    "By continuing you agree to Talngo's Term of use and confirm that you have read Talngo\n Privacy Policy" +
                        '\n',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                    ),
                  ),
                ),
              ),

              //continue button
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, top: 20),
                child: GestureDetector(
                  onTap: () {
                    register(
                      userNameController.text.toString(),
                      fullNameController.text.toString(),
                      emailController.text.toString(),
                      phoneController.text.toString(),
                      countryValue,
                      passwordController.text.toString(),
                      confirmPsswordController.text.toString(),
                      roleController.text.toString(),
                    );
                    // Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginBody()));
                   
                  },
                  child: Container(
                    height: 40,
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(5)),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 0, right: 0, top: 0, bottom: 0),
                      child: Center(
                          child: Text("Next",
                              style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  textStyle: TextStyle(color: Colors.white)))),
                    ),
                  ),
                ),
              ),

              const SizedBox(
                height: 20,
              ),

              Center(
                child: Text(
                  "Or SignUp with",
                  style: GoogleFonts.poppins(
                      fontSize: 14,
                      textStyle: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 0,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 0,
                    ),
                    InkWell(
                      onTap: () {
                        Colors.cyan;
                      },
                      child: Container(
                        height: 40,
                        width: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.transparent,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              offset: Offset(0, 2),
                              blurRadius: 6.0,
                            ),
                          ],
                          image: DecorationImage(
                            image: AssetImage("assets/icons/ic_ggl.png"),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.blue,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 2),
                            blurRadius: 6.0,
                          ),
                        ],
                        image: DecorationImage(
                          image: AssetImage("assets/icons/ic_fb.png"),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(
                  left: 0,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Already have an account?",
                      style: GoogleFonts.poppins(
                          fontSize: 12,
                          textStyle: TextStyle(color: Colors.white)),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    GestureDetector(
                      child: Text(
                        "SignIn Now",
                        style: GoogleFonts.poppins(
                            fontSize: 12,
                            textStyle: TextStyle(
                                color: secondaryColor,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void showCustomDialog(BuildContext context) {
  showDialog(
      context: context,
      barrierColor: Colors.grey.withOpacity(0.5),
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return Center(
            child: Container(
              height: 200,
              child: SizedBox.expand(
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: lGradient),
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Form(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text("Congratulations! ",
                                  textAlign: TextAlign.left,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      textStyle: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold))),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text(
                                  "Your account is successfully Created\n Click below button to Login! ",
                                  textAlign: TextAlign.left,
                                  style: GoogleFonts.poppins(
                                      fontSize: 12,
                                      textStyle:
                                          TextStyle(color: Colors.white))),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => LoginPage()));
                                  },
                                  child: Container(
                                    height: 35,
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 20, right: 20),
                                      child: Center(
                                          child: Text("Ok to Login!",
                                              style: GoogleFonts.poppins(
                                                  fontSize: 14,
                                                  textStyle: TextStyle(
                                                      color: Colors.white)))),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              margin: EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                  color: Colors.black, borderRadius: BorderRadius.circular(20)),
            ),
          );
        });
      });
}
