//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import modal_progress_hud_nsn
import path_provider_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ModalProgressHudNsnPlugin.register(with: registry.registrar(forPlugin: "ModalProgressHudNsnPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
